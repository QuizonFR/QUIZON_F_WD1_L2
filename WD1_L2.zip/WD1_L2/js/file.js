// Basic client side auth demo using localStorage.
// Not for production — for learning/demo only.

function getUsers() {
	const raw = localStorage.getItem('users');
	return raw ? JSON.parse(raw) : [];
}

function saveUsers(users) {
	localStorage.setItem('users', JSON.stringify(users));
}

function showMessage(el, text, isError = false) {
	if (!el) return;
	el.textContent = text;
	el.classList.toggle('error', isError);
}

document.addEventListener('DOMContentLoaded', function () {
	const signupForm = document.getElementById('signupForm');
	const loginForm = document.getElementById('loginForm');

	if (signupForm) {
		signupForm.addEventListener('submit', function (e) {
			e.preventDefault();
			const name = (document.getElementById('name') || {}).value || '';
			const email = (document.getElementById('email') || {}).value || '';
			const password = (document.getElementById('password') || {}).value || '';
			const messageEl = document.getElementById('signupMessage');

			if (!email || !password || !name) {
				showMessage(messageEl, 'Please fill out all fields.', true);
				return;
			}
			if (password.length < 6) {
				showMessage(messageEl, 'Password must be at least 6 characters long.', true);
				return;
			}

			const users = getUsers();
			const exists = users.find(u => u.email.toLowerCase() === email.toLowerCase());
			if (exists) {
				showMessage(messageEl, 'An account with that email already exists. Try logging in.', true);
				return;
			}

			// Save the new user
			users.push({ name, email, password });
			saveUsers(users);
			showMessage(messageEl, 'Account created! Redirecting to login...');
			setTimeout(() => {
				window.location.href = 'login.html';
			}, 1100);
		});
	}

	if (loginForm) {
		loginForm.addEventListener('submit', function (e) {
			e.preventDefault();
			const email = (document.getElementById('email') || {}).value || '';
			const password = (document.getElementById('password') || {}).value || '';
			const messageEl = document.getElementById('loginMessage');

			if (!email || !password) {
				showMessage(messageEl, 'Please enter your email and password.', true);
				return;
			}

			const users = getUsers();
			const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
			if (!user || user.password !== password) {
				showMessage(messageEl, 'Invalid email or password.', true);
				return;
			}

			showMessage(messageEl, `Welcome back, ${user.name}! Redirecting...`);
			setTimeout(() => {
				window.location.href = 'index.html';
			}, 1000);
		});
	}
});

